package Java_8;

public interface WebPageInterface {
	
	void header(String value);

}
